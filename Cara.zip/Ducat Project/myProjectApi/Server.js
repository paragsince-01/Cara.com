const express = require("express");
const cors = require('cors')
const app = express();

// Configure CORS to allow requests from http://localhost:5173
const corsOptions = {
    origin: 'http://localhost:5174',
  };
  
  app.use(cors(corsOptions)); // Use the cors middleware with the specified options
  


app.use(express.json());
const router1 = require("./Routing/Router.js");
const connectDB = require("./DataBase/Connectivity.js");
const Coustmer = require("./Models/Coustmer.js");
const router = require("./Routing/Router.js");
app.use(router1);
const serverStart = async () => {
  try {
    app.listen(5000);
    console.log("Server Started");
  } catch (error) {
    console.log("Error Occured");
  }
};
serverStart();
