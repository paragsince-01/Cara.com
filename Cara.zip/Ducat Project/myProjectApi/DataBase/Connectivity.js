// Import the Mongoose library:
const mongoose = require("mongoose");

// Create a connectDB as follows:
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(`mongodb://localhost:27017/database`, {
      useNewUrlParser: true,
      family: 4,
    });
    console.log(`MongoDB Connected`);
  } catch (error) {
    console.error(error.message);
    // process.exit(1);
  }
};
connectDB();
