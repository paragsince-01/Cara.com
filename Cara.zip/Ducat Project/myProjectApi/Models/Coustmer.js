const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const coustmerschema = new Schema({
  Name: {
    type: String,
    require: true,
  },
  Email: {
    type: String,
    require: true,
  },
  Subject: {
    type: String,
    require: true,
  },
  Text: {
    type: String,
    require: true,
  },
});
const coustmer = mongoose.model("coustmer", coustmerschema);
module.exports = coustmer;
