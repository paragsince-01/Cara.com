const express = require("express");
const coustmer = require("../Models/Coustmer");
const router = new express.Router();
const app = express();

//fetch the api ---------------------
router.get("/coustmers", async (req, res) => {
  // res.send("This is my project data");
  data = await coustmer.find();
  res.status(200).send(data);
  // console.log(data);
});
// fetch the api data on basis of name
router.get("/coustmers/:nm", async (req, res) => {
  // res.send("This is my project data");
    const name = req.params.nm;
  data = await coustmer.find({Name:name});
  res.status(200).send(data);
  // console.log(data);
});
//to post the data in to database----
router.post("/coustmers", async (req, res) => {
  // res.send("data posted");
  // console.log(req.body);
  try {
    const user = new coustmer(req.body);
    const data = await user.save();
    res.status(201).send(user);
  } catch (error) {
    res.status(400).send(error);
  }
});
//to delete the data on basis of name-------
router.delete("/coustmers/:nm", async (req, res) => {
  // res.send("data deleted");
  try {
    const name = req.params.nm;
    // console.log(email);
    const data = await coustmer.deleteOne({ Name: name });
    res.status(201).send(data);
  } catch (error) {
    res.status(400).send(error);
  }
});
//to uddate the data on basis of key -----
router.put("/coustmers/:nm/:enm/:sub/:txt", async (req, res) => {
  // res.send("data updated");
  try {
    const name = req.params.nm;
    const email = req.params.enm;
    const subject = req.params.sub;
    const text = req.params.txt;
    const data = await coustmer.updateOne(
      { Name: name },
      {
        $set: {
          Email: email,
          Subject: subject,
          Text: text,
        },
      }
    );
    res.status(201).send(data);
    // console.log(name, email, subject, text);
  } catch (error) {
    res.status(400).send(error);
  }
});
module.exports = router;
